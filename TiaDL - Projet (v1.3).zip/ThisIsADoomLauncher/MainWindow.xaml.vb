﻿Imports System.IO
Imports System.Reflection

Class MainWindow

    Private Sub Window_Loaded(sender As Object, e As RoutedEventArgs)

        Try

            ExeBasePath = Assembly.GetEntryAssembly.Location
            DirBasePath = Path.GetDirectoryName(ExeBasePath) & "\"

            CheckDirectories()

            If File.Exists(DirBasePath & "settings.txt") Then
                ParseSettingsFile()
            Else
                CreateSettingsFile()
            End If

            If TextBox_ResWidth.Text = "" Then
                TextBox_ResWidth.Background = New SolidColorBrush(Color.FromRgb(255, 200, 200))
            End If
            If TextBox_ResHeight.Text = "" Then
                TextBox_ResHeight.Background = New SolidColorBrush(Color.FromRgb(255, 200, 200))
            End If

        Catch ex As Exception
            WriteToLog(DateTime.Now & " - Error in 'Window_Loaded()'. Exception : " & ex.ToString)
        End Try

    End Sub


    Private Sub CheckDirectories()

        Try

            Dim setupError As Boolean = False
            Dim errorText As String = ""

            If Directory.Exists(DirBasePath & "gzdoom") Then
                DirGzdoom = DirBasePath & "gzdoom\"
            Else
                setupError = True
                errorText &= "/gzdoom/" & Environment.NewLine
            End If

            If Directory.Exists(DirBasePath & "iwads") Then
                DirIwads = DirBasePath & "iwads\"
            Else
                setupError = True
                errorText &= "/iwads/" & Environment.NewLine
            End If

            If Directory.Exists(DirBasePath & "mods") Then
                DirMods = DirBasePath & "mods\"
                PopulateBrutalVersions()
            Else
                setupError = True
                errorText &= "/mods/" & Environment.NewLine
            End If

            If Directory.Exists(DirBasePath & "music") Then
                DirMusic = DirBasePath & "music\"
            Else
                setupError = True
                errorText &= "/music/" & Environment.NewLine
            End If

            If Directory.Exists(DirBasePath & "wads") Then
                DirWads = DirBasePath & "wads\"
            Else
                setupError = True
                errorText &= "/wads/" & Environment.NewLine
            End If


            If setupError = True Then

                Dim output As String = String.Format("Setup error.{0}The following folders are not found :{1}{2}{3}",
                                                     Environment.NewLine & Environment.NewLine,
                                                     Environment.NewLine & errorText,
                                                     Environment.NewLine & "Did you move the exe file ?",
                                                     Environment.NewLine & "These directories should be visible right when you click 'Explore folder'")
                MessageBox.Show(output)
                Button_Launch.Foreground = Brushes.Red
                Button_Launch.FontSize = 18
                Button_Launch.Content = "Setup error"

                WriteToLog(DateTime.Now & " - Setup error : director[y-ies] not found.")
            End If

        Catch ex As Exception
            WriteToLog(DateTime.Now & " - Error in 'CheckDirectories()'. Exception : " & ex.ToString)
        End Try


    End Sub


    Private Sub ParseSettingsFile()

        Try

            Dim value As String

            'Width
            value = GetValueFromFile(DirBasePath & "settings.txt", "width", 0)
            If Integer.TryParse(value, LoadedWidth) Then
                TextBox_ResWidth.Text = CType(LoadedWidth, String)
            End If


            'Height
            value = GetValueFromFile(DirBasePath & "settings.txt", "height", 0)
            If Integer.TryParse(value, LoadedHeight) Then
                TextBox_ResHeight.Text = CType(LoadedHeight, String)
            End If


            'Fullscreen
            value = GetValueFromFile(DirBasePath & "settings.txt", "fullscreen", 0)
            If Integer.TryParse(value, LoadedFullscreen) Then
                If LoadedFullscreen = 1 Then
                    CheckBox_Fullscreen.IsChecked = True
                End If
            End If


            'Turbo mode
            value = GetValueFromFile(DirBasePath & "settings.txt", "turbo", 0)
            If Integer.TryParse(value, LoadedTurbo) Then
                If LoadedTurbo = 1 Then
                    CheckBox_EnableTurbo.IsChecked = True
                End If
            End If


            'Favourite BD version
            value = GetValueFromFile(DirBasePath & "settings.txt", "favouriteBDversion", 0)

            If Not value = "" Then
                Dim fileInfo_favBD As FileInfo = New FileInfo(value)

                If fileInfo_favBD.Extension = ".pk3" Then
                    LoadedFavouriteBrutal = value
                    TextBox_FavBrutalVersion.Text = LoadedFavouriteBrutal
                Else
                    MessageBox.Show("Error : The value found for 'favouriteBDversion' in 'settings.txt' isn't refering to a valid .pk3 file ")
                End If
            End If


            'Last Iwad launched
            value = GetValueFromFile(DirBasePath & "settings.txt", "lastIwadLaunched", 0)

            If Not value = "" Then
                Dim fileInfo_iwad As FileInfo = New FileInfo(value)

                If fileInfo_iwad.Extension = ".wad" Then
                    LoadedLastIwadLaunched = fileInfo_iwad.Name
                    TextBox_ShowIwadToLaunch.Text = LoadedLastIwadLaunched
                Else
                    MessageBox.Show("Error : The value found for 'lastIwadLaunched' in 'settings.txt' isn't refering to a valid .wad file ")
                End If
            End If


            'Last Wad launched
            value = GetValueFromFile(DirBasePath & "settings.txt", "lastWadLaunched", 0)

            If Not value = "" Then
                Dim fileInfo_wad As FileInfo = New FileInfo(value)

                If fileInfo_wad.Extension = ".wad" Or fileInfo_wad.Extension = ".pk3" Then
                    LoadedLastWadLaunched = fileInfo_wad.FullName
                    TextBox_ShowWadToLaunch.Text = fileInfo_wad.Name
                Else
                    MessageBox.Show("Error : The value found for 'lastWadLaunched' in 'settings.txt' isn't refering to a valid .wad/.pk3 file ")
                End If
            End If


        Catch ex As Exception
                WriteToLog(DateTime.Now & " - Error in 'ParseSettingsFile()'. Exception : " & ex.ToString)
        End Try

    End Sub


    Private Sub PopulateBrutalVersions()

        Try

            Dim files() = Directory.GetFiles(DirMods)

            For Each afile As String In files
                Dim name As String = New FileInfo(afile).Name
                ComboBox_BrutalDoomVersion.Items.Add(name)
            Next

        Catch ex As Exception
            WriteToLog(DateTime.Now & " - Error in 'PopulateBrutalVersions()'. Exception : " & ex.ToString)
        End Try

    End Sub


    Private Sub CreateSettingsFile()

        Try

            Using writer As StreamWriter = New StreamWriter(DirBasePath & "settings.txt")

                writer.WriteLine("width ")
                writer.WriteLine("height ")
                writer.WriteLine("fullscreen ")
                writer.WriteLine("turbo ")
                writer.WriteLine("favouriteBDversion ")
                writer.WriteLine("lastIwadLaunched ")
                writer.WriteLine("lastWadLaunched ")

            End Using

        Catch ex As Exception
            WriteToLog(DateTime.Now & " - Error in 'CreateSettingsFile()'. Exception : " & ex.ToString)
        End Try

    End Sub







    Private Sub TextBox_iwad_file_PreviewDragOver(sender As Object, e As DragEventArgs)

        e.Handled = True

    End Sub

    Private Sub TextBox_iwad_file_Drop(sender As Object, e As DragEventArgs)

        Try

            Dim file() As String = CType(e.Data.GetData(DataFormats.FileDrop), String())
            Dim fileName = file(0)
            Dim fileInfo As FileInfo = New FileInfo(fileName)

            Dim fn = fileInfo.Name.ToLower

            If fn = "doom.wad" Or fn = "doom2.wad" Or fn = "tnt.wad" Or fn = "plutonia.wad" Then
                TextBox_iwad_file.ClearValue(FontStyleProperty)
                TextBox_iwad_file.ClearValue(ForegroundProperty)
                TextBox_iwad_file.Text = fileName

                TextBox_ShowIwadToLaunch.Text = fileInfo.Name
            Else
                MessageBox.Show("Error : incorrect IWAD file")
                ResetInput_iwad(False)
            End If

        Catch ex As Exception
            WriteToLog(DateTime.Now & " - Error in 'TextBox_iwad_file_Drop()'. Exception : " & ex.ToString)
        End Try

    End Sub

    Private Sub Button_Reset_iwad_input_Click(sender As Object, e As RoutedEventArgs) Handles Button_Reset_iwad_input.Click

        ResetInput_iwad(True)

    End Sub

    Private Sub ResetInput_iwad(ByVal byUser As Boolean)

        TextBox_iwad_file.FontStyle = FontStyles.Italic
        TextBox_iwad_file.Foreground = Brushes.DarkGray
        TextBox_iwad_file.Text = "Drop an IWAD file here ..."

        If byUser Then
            TextBox_ShowIwadToLaunch.Text = ""
        End If

    End Sub

    Private Sub Button_SetIwad_Doom2_Click(sender As Object, e As RoutedEventArgs) Handles Button_SetIwad_Doom2.Click

        TextBox_iwad_file.ClearValue(FontStyleProperty)
        TextBox_iwad_file.ClearValue(ForegroundProperty)

        Dim fileInfo As FileInfo = New FileInfo(DirIwads & "Doom2.wad")

        TextBox_iwad_file.Text = fileInfo.FullName
        TextBox_ShowIwadToLaunch.Text = fileInfo.Name

    End Sub





    Private Sub TextBox_wad_file_PreviewDragOver(sender As Object, e As DragEventArgs)

        e.Handled = True

    End Sub

    Private Sub TextBox_wad_file_Drop(sender As Object, e As DragEventArgs)

        Try

            Dim file() As String = CType(e.Data.GetData(DataFormats.FileDrop), String())

            Dim fileInfo As FileInfo = New FileInfo(file(0))
            Dim file_ext = fileInfo.Extension

            If file_ext = ".wad" Or file_ext = ".pk3" Then


                Dim lowername = fileInfo.Name.ToLower

                If lowername = "doom.wad" Or lowername = "doom2.wad" Or lowername = "tnt.wad" Or lowername = "plutonia.wad" Then
                    MessageBox.Show("Error : this file is an IWAD")

                Else
                    TextBox_wad_file.ClearValue(FontStyleProperty)
                    TextBox_wad_file.ClearValue(ForegroundProperty)
                    TextBox_wad_file.Text = fileInfo.FullName

                    TextBox_ShowWadToLaunch.Text = fileInfo.Name
                End If

            Else
                MessageBox.Show("Error : not a .wad/.pk3 file")
                ResetInput_wad(False)
            End If

        Catch ex As Exception
            WriteToLog(DateTime.Now & " - Error in 'TextBox_wad_file_Drop()'. Exception : " & ex.ToString)
        End Try

    End Sub

    Private Sub Button_Reset_wad_input_Click(sender As Object, e As RoutedEventArgs) Handles Button_Reset_wad_input.Click

        ResetInput_wad(True)

    End Sub

    Private Sub ResetInput_wad(ByVal byUser As Boolean)

        TextBox_wad_file.FontStyle = FontStyles.Italic
        TextBox_wad_file.Foreground = Brushes.DarkGray
        TextBox_wad_file.Text = "Drop a .wad/.pk3 file here ..."

        If byUser Then
            TextBox_ShowWadToLaunch.Text = ""
        End If

    End Sub







    Private Sub Button_Reset_FoundBru_input_Click(sender As Object, e As RoutedEventArgs) Handles Button_Reset_FoundBru_input.Click

        ComboBox_BrutalDoomVersion.SelectedItem = Nothing

    End Sub

    Private Sub Button_Reset_FavBru_input_Click(sender As Object, e As RoutedEventArgs) Handles Button_Reset_FavBru_input.Click

        TextBox_FavBrutalVersion.Text = ""

    End Sub

    Private Sub TextBox_Resolution_Width_TextChanged(sender As Object, e As TextChangedEventArgs) Handles TextBox_ResWidth.TextChanged

        Dim value_in As String = TextBox_ResWidth.Text
        Dim value_out As Integer = 0

        If Integer.TryParse(value_in, value_out) Then
            TextBox_ResWidth.Background = New SolidColorBrush(Color.FromRgb(255, 255, 255))
        Else
            TextBox_ResWidth.Background = New SolidColorBrush(Color.FromRgb(255, 200, 200))
        End If

    End Sub

    Private Sub TextBox_Resolution_Height_TextChanged(sender As Object, e As TextChangedEventArgs) Handles TextBox_ResHeight.TextChanged

        Dim value_in As String = TextBox_ResHeight.Text
        Dim value_out As Integer = 0

        If Integer.TryParse(value_in, value_out) Then
            TextBox_ResHeight.Background = New SolidColorBrush(Color.FromRgb(255, 255, 255))
        Else
            TextBox_ResHeight.Background = New SolidColorBrush(Color.FromRgb(255, 200, 200))
        End If

    End Sub

    Private Sub Button_DefineFavBrutalVersion_Click(sender As Object, e As RoutedEventArgs) Handles Button_DefineFavBrutalVersion.Click
        TextBox_FavBrutalVersion.Text = ComboBox_BrutalDoomVersion.Text
    End Sub







    Private Sub Button_exploreFolder_Click(sender As Object, e As RoutedEventArgs) Handles Button_exploreFolder.Click
        Process.Start(DirBasePath)
    End Sub

    Private Sub Button_SearchDoomWorldDB_Click(sender As Object, e As RoutedEventArgs) Handles Button_SearchDoomWorldDB.Click
        Dim url As String = "https://www.doomworld.com/idgames/levels/"
        Process.Start(url)
    End Sub







    Private Sub Button_Launch_Click(sender As Object, e As RoutedEventArgs) Handles Button_Launch.Click

        Try
            If Button_Launch.Content = "Play" Then
                Dim ok As Boolean = True

                If TextBox_ResWidth.Text = "" Or TextBox_ResHeight.Text = "" Then
                    MessageBox.Show("Error : please choose a screen resolution")
                    ok = False
                End If

                If TextBox_ShowIwadToLaunch.Text = "" Then
                    MessageBox.Show("Error : an IWAD must be selected")
                    ok = False
                End If

                If ok Then
                    Dim cli = BuildCommandLineInstructions()
                    LaunchProcess(cli) 'Launch the game with command line parameters
                    WriteSettings()
                End If
            Else
                Dim eNl = Environment.NewLine
                Dim output As String = String.Format("Setup error : The TiaDL folder must contain :{0}{1}{2}{3}{4}{5}{6}{7}{8}{9}{10}{11}",
                                                     Environment.NewLine,
                                                     Environment.NewLine & "- /gzdoom/ folder",
                                                     Environment.NewLine & "- /iwads/ folder",
                                                     Environment.NewLine & "- /mods/ folder",
                                                     Environment.NewLine & "- /music/ folder",
                                                     Environment.NewLine & "- /wads/ folder",
                                                     Environment.NewLine & "- 'info.txt' file (optional)",
                                                     Environment.NewLine & "- 'log.txt' file (optional)",
                                                     Environment.NewLine & "- 'settings.txt' file (optional)",
                                                     Environment.NewLine & "- 'ThisIsADoomLauncher.exe' executable",
                                                     Environment.NewLine,
                                                     Environment.NewLine & "Please check picture 'help.PNG' for further help")
                MessageBox.Show(output)

            End If

        Catch ex As Exception
            WriteToLog(DateTime.Now & " - Error in 'Button_Launch_Click()'. Exception : " & ex.ToString)
        End Try

    End Sub


    Private Sub LaunchProcess(ByVal args As String)

        Dim psi As New ProcessStartInfo("cmd.exe") With {
            .UseShellExecute = False,
            .CreateNoWindow = True,
            .Arguments = args
        }

        Process.Start(psi)

    End Sub


    Private Function BuildCommandLineInstructions()

        Try

            'Parse values
            ConfirmedWidth = String.Format(" -width {0}", TextBox_ResWidth.Text)
            ConfirmedHeight = String.Format(" -height {0}", TextBox_ResHeight.Text)
            ConfirmedFullscreen = String.Format(" +fullscreen {0}", CInt(Int(CheckBox_Fullscreen.IsChecked)))

            ConfirmedIwad = ""

            If Not TextBox_ShowIwadToLaunch.Text = "" Then
                ConfirmedIwad += " -iwad " & """" & DirIwads & TextBox_ShowIwadToLaunch.Text & """"
            End If

            ConfirmedWad = ""

            If Not TextBox_ShowWadToLaunch.Text = "" Then

                If File.Exists(DirWads & TextBox_ShowWadToLaunch.Text) Then
                    ConfirmedWad += " -file " & """" & DirWads & TextBox_ShowWadToLaunch.Text & """"
                Else
                    If TextBox_wad_file.Text = "Drop a .wad/.pk3 file here ..." Then
                        ConfirmedWad += " -file " & """" & LoadedLastWadLaunched & """"
                    Else
                        ConfirmedWad += " -file " & """" & TextBox_wad_file.Text & """"
                    End If
                End If

            End If

            ConfirmedBdVersion = ""

            If Not TextBox_FavBrutalVersion.Text = "" Then
                ConfirmedBdVersion += " -file " & """" & DirMods & TextBox_FavBrutalVersion.Text & """"
            Else
                ConfirmedBdVersion += " -file " & """" & DirMods & ComboBox_BrutalDoomVersion.Text & """"
            End If

            ConfirmedMusicMod = ""

            If CheckBox_Load_DoomMetal.IsChecked Then
                ConfirmedMusicMod += " -file " & """" & DirMusic & "DoomMetalVol4.wad" & """"
            End If

            ConfirmedTurbo = ""

            If CheckBox_EnableTurbo.IsChecked Then
                ConfirmedTurbo += " -turbo 120"
            End If

            'Build the string with arguments
            Dim args = "/c start " & """""" & " " & """" & DirGzdoom & "gzdoom.exe" & """" &
                       ConfirmedWidth &
                       ConfirmedHeight &
                       ConfirmedFullscreen &
                       ConfirmedIwad &
                       ConfirmedWad &
                       ConfirmedBdVersion &
                       ConfirmedMusicMod &
                       ConfirmedTurbo

            'DEBUG
            WriteToLog(DateTime.Now & " - CommandLine :" & Environment.NewLine & args)

            Return args

        Catch ex As Exception
            WriteToLog(DateTime.Now & " - Error in 'BuildCommandLineInstructions()'. Exception : " & ex.ToString)
            Return ""
        End Try

    End Function



    Private Sub WriteSettings()

        Try

            Dim line As Integer = 0

            If Not LoadedWidth = CInt(TextBox_ResWidth.Text) Then
                line = GetLineInFile(DirBasePath & "settings.txt", "width", 0)
                WriteLineInFile("width " & TextBox_ResWidth.Text, DirBasePath & "settings.txt", line)
            End If

            If Not LoadedHeight = CInt(TextBox_ResHeight.Text) Then
                line = GetLineInFile(DirBasePath & "settings.txt", "height", 0)
                WriteLineInFile("height " & TextBox_ResHeight.Text, DirBasePath & "settings.txt", line)
            End If

            If Not LoadedFullscreen = CInt(Int(CheckBox_Fullscreen.IsChecked)) Then
                line = GetLineInFile(DirBasePath & "settings.txt", "fullscreen", 0)
                WriteLineInFile("fullscreen " & CInt(Int(CheckBox_Fullscreen.IsChecked)).ToString, DirBasePath & "settings.txt", line)
            End If

            If Not LoadedTurbo = CInt(Int(CheckBox_EnableTurbo.IsChecked)) Then
                line = GetLineInFile(DirBasePath & "settings.txt", "turbo", 0)
                WriteLineInFile("turbo " & CInt(Int(CheckBox_EnableTurbo.IsChecked)).ToString, DirBasePath & "settings.txt", line)
            End If

            If Not LoadedFavouriteBrutal = TextBox_FavBrutalVersion.Text Then
                line = GetLineInFile(DirBasePath & "settings.txt", "favouriteBDversion", 0)
                WriteLineInFile("favouriteBDversion " & TextBox_FavBrutalVersion.Text, DirBasePath & "settings.txt", line)
            End If

            If Not LoadedLastIwadLaunched = TextBox_ShowIwadToLaunch.Text Then
                line = GetLineInFile(DirBasePath & "settings.txt", "lastIwadLaunched", 0)
                WriteLineInFile("lastIwadLaunched " & TextBox_ShowIwadToLaunch.Text, DirBasePath & "settings.txt", line)
            End If


            ' Consider the case of dropped wad file

            If TextBox_ShowWadToLaunch.Text = "" Then

                ' Just an Iwad launched
                line = GetLineInFile(DirBasePath & "settings.txt", "lastWadLaunched", 0)
                WriteLineInFile("lastWadLaunched ", DirBasePath & "settings.txt", line)

            Else
                If TextBox_wad_file.Text = "Drop a .wad/.pk3 file here ..." Then

                    If File.Exists(DirWads & TextBox_ShowWadToLaunch.Text) Then

                        Dim fileInfo As FileInfo = New FileInfo(TextBox_ShowWadToLaunch.Text)
                        line = GetLineInFile(DirBasePath & "settings.txt", "lastWadLaunched", 0)
                        WriteLineInFile("lastWadLaunched " & fileInfo.Name, DirBasePath & "settings.txt", line)
                    Else
                        ' so it may come from the LastLaunchedWad
                        If File.Exists(LoadedLastWadLaunched) Then
                            line = GetLineInFile(DirBasePath & "settings.txt", "lastWadLaunched", 0)
                            WriteLineInFile("lastWadLaunched " & LoadedLastWadLaunched, DirBasePath & "settings.txt", line)
                        End If
                    End If
                Else

                    Dim fileInfo As FileInfo = New FileInfo(TextBox_wad_file.Text)
                    line = GetLineInFile(DirBasePath & "settings.txt", "lastWadLaunched", 0)
                    WriteLineInFile("lastWadLaunched " & fileInfo.FullName, DirBasePath & "settings.txt", line)

                End If
            End If

        Catch ex As Exception
            WriteToLog(DateTime.Now & " - Error in 'WriteSettingsInFile()'. Exception : " & ex.ToString)
        End Try

    End Sub







    Private Sub Button_Preset1_Click(sender As Object, e As RoutedEventArgs) Handles Button_Preset1.Click

        'Utimate Doom
        ConfirmedIwad = "Doom.wad"
        ConfirmedWad = ""

        TextBox_ShowIwadToLaunch.Text = ConfirmedIwad
        TextBox_ShowWadToLaunch.Text = ConfirmedWad

    End Sub

    Private Sub Button_Preset2_Click(sender As Object, e As RoutedEventArgs) Handles Button_Preset2.Click

        'Doom 2
        ConfirmedIwad = "Doom2.wad"
        ConfirmedWad = ""

        TextBox_ShowIwadToLaunch.Text = ConfirmedIwad
        TextBox_ShowWadToLaunch.Text = ConfirmedWad

    End Sub

    Private Sub Button_Preset3_Click(sender As Object, e As RoutedEventArgs) Handles Button_Preset3.Click

        'TNT
        ConfirmedIwad = "TNT.wad"
        ConfirmedWad = ""

        TextBox_ShowIwadToLaunch.Text = ConfirmedIwad
        TextBox_ShowWadToLaunch.Text = ConfirmedWad

    End Sub

    Private Sub Button_Preset4_Click(sender As Object, e As RoutedEventArgs) Handles Button_Preset4.Click

        'Plutonia
        ConfirmedIwad = "Plutonia.wad"
        ConfirmedWad = ""

        TextBox_ShowIwadToLaunch.Text = ConfirmedIwad
        TextBox_ShowWadToLaunch.Text = ConfirmedWad

    End Sub

    Private Sub Button_Preset5_Click(sender As Object, e As RoutedEventArgs) Handles Button_Preset5.Click

        '2002 A Doom Odyssey
        ConfirmedIwad = "Doom.wad"
        ConfirmedWad = "2002ad10.wad"

        TextBox_ShowIwadToLaunch.Text = ConfirmedIwad
        TextBox_ShowWadToLaunch.Text = ConfirmedWad

    End Sub

    Private Sub Button_Preset6_Click(sender As Object, e As RoutedEventArgs) Handles Button_Preset6.Click

        'Icarus : Alien Vanguard
        ConfirmedIwad = "Doom2.wad"
        ConfirmedWad = "ICARUS.wad"

        TextBox_ShowIwadToLaunch.Text = ConfirmedIwad
        TextBox_ShowWadToLaunch.Text = ConfirmedWad

    End Sub

    Private Sub Button_Preset7_Click(sender As Object, e As RoutedEventArgs) Handles Button_Preset7.Click

        'Requiem
        ConfirmedIwad = "Doom2.wad"
        ConfirmedWad = "Requiem.wad"

        TextBox_ShowIwadToLaunch.Text = ConfirmedIwad
        TextBox_ShowWadToLaunch.Text = ConfirmedWad

    End Sub

    Private Sub Button_Preset8_Click(sender As Object, e As RoutedEventArgs) Handles Button_Preset8.Click

        'Plutonia 2
        ConfirmedIwad = "Doom2.wad"
        ConfirmedWad = "PL2.wad"

        TextBox_ShowIwadToLaunch.Text = ConfirmedIwad
        TextBox_ShowWadToLaunch.Text = ConfirmedWad

    End Sub

    Private Sub Button_Preset9_Click(sender As Object, e As RoutedEventArgs) Handles Button_Preset9.Click

        'Hell Revealed
        ConfirmedIwad = "Doom2.wad"
        ConfirmedWad = "hr.wad"

        TextBox_ShowIwadToLaunch.Text = ConfirmedIwad
        TextBox_ShowWadToLaunch.Text = ConfirmedWad

    End Sub

    Private Sub Button_Preset10_Click(sender As Object, e As RoutedEventArgs) Handles Button_Preset10.Click

        'Hell Revealed 2
        ConfirmedIwad = "Doom2.wad"
        ConfirmedWad = "hr2final.wad"

        TextBox_ShowIwadToLaunch.Text = ConfirmedIwad
        TextBox_ShowWadToLaunch.Text = ConfirmedWad

    End Sub

    Private Sub Button_Preset11_Click(sender As Object, e As RoutedEventArgs) Handles Button_Preset11.Click

        'DTS-T
        ConfirmedIwad = "Doom2.wad"
        ConfirmedWad = "DTS-T.pk3"

        TextBox_ShowIwadToLaunch.Text = ConfirmedIwad
        TextBox_ShowWadToLaunch.Text = ConfirmedWad

    End Sub

    Private Sub Button_Preset12_Click(sender As Object, e As RoutedEventArgs) Handles Button_Preset12.Click

        'Plutonia Revisited
        ConfirmedIwad = "Doom2.wad"
        ConfirmedWad = "PRCP.wad"

        TextBox_ShowIwadToLaunch.Text = ConfirmedIwad
        TextBox_ShowWadToLaunch.Text = ConfirmedWad

    End Sub


End Class
