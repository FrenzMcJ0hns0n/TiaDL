﻿Module ObjectsAndValues


#Region "Paths and folders"

    Dim exe_basePath As String
    Dim dir_basePath As String
    Dim dir_gzdoom As String
    Dim dir_iwads As String
    Dim dir_mods As String
    Dim dir_music As String
    Dim dir_wads As String

    Public Property ExeBasePath As String
        Get
            Return exe_basePath
        End Get
        Set(value As String)
            exe_basePath = value
        End Set
    End Property

    Public Property DirBasePath As String
        Get
            Return dir_basePath
        End Get
        Set(value As String)
            dir_basePath = value
        End Set
    End Property

    Public Property DirGzdoom As String
        Get
            Return dir_gzdoom
        End Get
        Set(value As String)
            dir_gzdoom = value
        End Set
    End Property

    Public Property DirIwads As String
        Get
            Return dir_iwads
        End Get
        Set(value As String)
            dir_iwads = value
        End Set
    End Property

    Public Property DirMods As String
        Get
            Return dir_mods
        End Get
        Set(value As String)
            dir_mods = value
        End Set
    End Property

    Public Property DirMusic As String
        Get
            Return dir_music
        End Get
        Set(value As String)
            dir_music = value
        End Set
    End Property

    Public Property DirWads As String
        Get
            Return dir_wads
        End Get
        Set(value As String)
            dir_wads = value
        End Set
    End Property

#End Region


#Region "Parameters loaded"

    Dim l_width As Integer
    Dim l_height As Integer
    Dim l_fullscreen As Integer
    Dim l_turbo As Integer
    Dim l_favBrutalVersion As String
    Dim l_lastIwadLaunched As String
    Dim l_lastWadLaunched As String

    Public Property LoadedWidth As Integer
        Get
            Return l_width
        End Get
        Set(value As Integer)
            l_width = value
        End Set
    End Property

    Public Property LoadedHeight As Integer
        Get
            Return l_height
        End Get
        Set(value As Integer)
            l_height = value
        End Set
    End Property

    Public Property LoadedFullscreen As Integer
        Get
            Return l_fullscreen
        End Get
        Set(value As Integer)
            l_fullscreen = value
        End Set
    End Property

    Public Property LoadedTurbo As Integer
        Get
            Return l_turbo
        End Get
        Set(value As Integer)
            l_turbo = value
        End Set
    End Property

    Public Property LoadedFavouriteBrutal As String
        Get
            Return l_favBrutalVersion
        End Get
        Set(value As String)
            l_favBrutalVersion = value
        End Set
    End Property

    Public Property LoadedLastIwadLaunched As String
        Get
            Return l_lastIwadLaunched
        End Get
        Set(value As String)
            l_lastIwadLaunched = value
        End Set
    End Property

    Public Property LoadedLastWadLaunched As String
        Get
            Return l_lastWadLaunched
        End Get
        Set(value As String)
            l_lastWadLaunched = value
        End Set
    End Property

#End Region


#Region "Parameters confirmed"

    Dim c_width As String
    Dim c_height As String
    Dim c_fullscreen As String
    Dim c_iwad As String
    Dim c_wad As String
    Dim c_bdversion As String
    Dim c_musicmod As String
    Dim c_turbo As String

    Public Property ConfirmedWidth As String
        Get
            Return c_width
        End Get
        Set(value As String)
            c_width = value
        End Set
    End Property

    Public Property ConfirmedHeight As String
        Get
            Return c_height
        End Get
        Set(value As String)
            c_height = value
        End Set
    End Property

    Public Property ConfirmedFullscreen As String
        Get
            Return c_fullscreen
        End Get
        Set(value As String)
            c_fullscreen = value
        End Set
    End Property

    Public Property ConfirmedIwad As String
        Get
            Return c_iwad
        End Get
        Set(value As String)
            c_iwad = value
        End Set
    End Property

    Public Property ConfirmedWad As String
        Get
            Return c_wad
        End Get
        Set(value As String)
            c_wad = value
        End Set
    End Property

    Public Property ConfirmedBdVersion As String
        Get
            Return c_bdversion
        End Get
        Set(value As String)
            c_bdversion = value
        End Set
    End Property

    Public Property ConfirmedMusicMod As String
        Get
            Return c_musicmod
        End Get
        Set(value As String)
            c_musicmod = value
        End Set
    End Property

    Public Property ConfirmedTurbo As String
        Get
            Return c_turbo
        End Get
        Set(value As String)
            c_turbo = value
        End Set
    End Property

#End Region

End Module
