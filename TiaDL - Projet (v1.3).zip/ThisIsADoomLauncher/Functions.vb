﻿Imports System.IO

Module Functions


    Function GetValueFromFile(ByVal file As String, ByVal key As String, ByVal pos As Integer) As String

        Dim line As String = ""
        Dim count As Integer = 0

        Try
            Using reader As StreamReader = New StreamReader(file)

                Do While (Not line Is Nothing)

                    line = reader.ReadLine

                    If line.StartsWith(key) Then
                        If count = pos Then
                            If line.Length > key.Length Then

                                'Subtract the key length, so the value remains
                                Dim value As String = line.Substring(key.Length)

                                'Return the value, without any blank spance before/after
                                Return value.Trim

                            Else
                                Return "No value"
                            End If
                        Else
                            count += 1
                        End If
                    End If

                Loop

                'Value not found
                Return "No match"

            End Using

        Catch ex As Exception
            'Not used : just for code clarity
            Return "Error parsing the file"

        End Try

    End Function




    Function GetLineInFile(ByVal file As String, ByVal expr As String, ByVal pos As Integer) As Integer

        Dim line As String = ""
        Dim counter As Integer = 0
        Dim skipped As Integer = 0

        Try
            Using reader As StreamReader = New StreamReader(file)

                Do While (Not line Is Nothing)

                    line = reader.ReadLine
                    counter += 1

                    If line.StartsWith(expr) Then
                        If skipped = pos Then

                            'Value found : Return line number
                            Return counter

                        Else
                            skipped += 1

                        End If
                    End If

                Loop

                'Value not found
                Return 0

            End Using

        Catch ex As Exception
            'Error reading the file
            Return 0

        End Try

    End Function



    Sub WriteToLog(ByVal text As String)
        Using StreamWriter As New StreamWriter(DirBasePath & "log.txt", True)
            StreamWriter.WriteLine(text)
        End Using
    End Sub



    Sub WriteLineInFile(ByVal newText As String, ByVal fileToRead As String, ByVal lineToEdit As Integer)

        If Not lineToEdit = 0 Then

            Dim lines() As String = File.ReadAllLines(fileToRead)
            lines(lineToEdit - 1) = newText
            File.WriteAllLines(fileToRead, lines)

        End If

    End Sub


End Module
