﻿Module ObjectsAndValues

#Region "Paths"

    Private p_exefilepath As String
    Private p_rootdirpath As String
    Private p_gzdoomdirpath As String
    Private p_iwaddirpath As String
    Private p_levelsdirpath As String
    Private p_moddirpath As String
    Private p_musicdirpath As String

    Public Property ExePath As String
        Get
            Return p_exefilepath
        End Get
        Set(value As String)
            p_exefilepath = value
        End Set
    End Property

    Public Property RootDirPath As String
        Get
            Return p_rootdirpath
        End Get
        Set(value As String)
            p_rootdirpath = value
        End Set
    End Property

    Public Property GzdoomDirPath As String
        Get
            Return p_gzdoomdirpath
        End Get
        Set(value As String)
            p_gzdoomdirpath = value
        End Set
    End Property

    Public Property IwadDirPath As String
        Get
            Return p_iwaddirpath
        End Get
        Set(value As String)
            p_iwaddirpath = value
        End Set
    End Property

    Public Property LevelDirPath As String
        Get
            Return p_levelsdirpath
        End Get
        Set(value As String)
            p_levelsdirpath = value
        End Set
    End Property

    Public Property ModDirPath As String
        Get
            Return p_moddirpath
        End Get
        Set(value As String)
            p_moddirpath = value
        End Set
    End Property

    Public Property MusicDirPath As String
        Get
            Return p_musicdirpath
        End Get
        Set(value As String)
            p_musicdirpath = value
        End Set
    End Property

#End Region


#Region "Parameters loaded"

    Private l_width As Integer
    Private l_height As Integer
    Private l_fullscreen As Integer
    Private l_usebrutaldoom As Boolean
    Private l_brutaldoomversion As String
    Private l_lastlaunchediwad As String
    Private l_lastlaunchedlevel As String
    Private l_turbo As Integer

    Public Property LoadedWidth As Integer
        Get
            Return l_width
        End Get
        Set(value As Integer)
            l_width = value
        End Set
    End Property

    Public Property LoadedHeight As Integer
        Get
            Return l_height
        End Get
        Set(value As Integer)
            l_height = value
        End Set
    End Property

    Public Property LoadedFullscreen As Integer
        Get
            Return l_fullscreen
        End Get
        Set(value As Integer)
            l_fullscreen = value
        End Set
    End Property

    Public Property LoadedUseBrutalDoom As Boolean
        Get
            Return l_usebrutaldoom
        End Get
        Set(value As Boolean)
            l_usebrutaldoom = value
        End Set
    End Property

    Public Property LoadedBrutalDoomVersion As String
        Get
            Return l_brutaldoomversion
        End Get
        Set(value As String)
            l_brutaldoomversion = value
        End Set
    End Property

    Public Property LoadedLastLaunchedIwad As String
        Get
            Return l_lastlaunchediwad
        End Get
        Set(value As String)
            l_lastlaunchediwad = value
        End Set
    End Property

    Public Property LoadedLastLaunchedLevel As String
        Get
            Return l_lastlaunchedlevel
        End Get
        Set(value As String)
            l_lastlaunchedlevel = value
        End Set
    End Property

    Public Property LoadedTurbo As Integer
        Get
            Return l_turbo
        End Get
        Set(value As Integer)
            l_turbo = value
        End Set
    End Property

#End Region


#Region "Parameters confirmed"

    Private c_width As String
    Private c_height As String
    Private c_fullscreen As Boolean
    Private c_iwad As String
    Private c_level As String
    Private c_usebrutaldoom As Boolean
    Private c_brutaldoomversion As String
    Private c_musicmod As String
    Private c_turbo As String


    Public Property ConfirmedWidth As String
        Get
            Return c_width
        End Get
        Set(value As String)
            c_width = value
        End Set
    End Property

    Public Property ConfirmedHeight As String
        Get
            Return c_height
        End Get
        Set(value As String)
            c_height = value
        End Set
    End Property

    Public Property ConfirmedFullscreen As Boolean
        Get
            Return c_fullscreen
        End Get
        Set(value As Boolean)
            c_fullscreen = value
        End Set
    End Property

    Public Property ConfirmedIwad As String
        Get
            Return c_iwad
        End Get
        Set(value As String)
            c_iwad = value
        End Set
    End Property

    Public Property ConfirmedLevel As String
        Get
            Return c_level
        End Get
        Set(value As String)
            c_level = value
        End Set
    End Property

    Public Property ConfirmedUseBrutalDoom() As Boolean
        Get
            Return c_usebrutaldoom
        End Get
        Set(ByVal value As Boolean)
            c_usebrutaldoom = value
        End Set
    End Property

    Public Property ConfirmedBrutalDoomVersion As String
        Get
            Return c_brutaldoomversion
        End Get
        Set(value As String)
            c_brutaldoomversion = value
        End Set
    End Property

    Public Property ConfirmedMusicMod As String
        Get
            Return c_musicmod
        End Get
        Set(value As String)
            c_musicmod = value
        End Set
    End Property

    Public Property ConfirmedTurbo As String
        Get
            Return c_turbo
        End Get
        Set(value As String)
            c_turbo = value
        End Set
    End Property

#End Region

End Module
