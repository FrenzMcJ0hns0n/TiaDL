﻿Imports System.IO

Module Functions

    ''' 
    ''' Utilities
    '''

    Function GetValueFromFile(ByVal file As String, ByVal key As String, ByVal pos As Integer) As String

        Dim line As String = ""
        Dim count As Integer = 0

        Try

            Using reader As StreamReader = New StreamReader(file)

                Do While (Not line Is Nothing)

                    line = reader.ReadLine

                    If line.StartsWith(key) Then
                        If count = pos Then

                            If line.Length > key.Length Then

                                'Subtract the key length, so the value remains
                                Dim value As String = line.Substring(key.Length)

                                'Return the value, without any blank spance before/after
                                Return value.Trim

                            Else

                                Return "No value" 'Better use "" to match smthng smwhr ?

                            End If

                        Else
                            count += 1
                        End If
                    End If

                Loop

                'Value not found
                Return "No match"

            End Using

        Catch ex As Exception

            Return "Error parsing the file" 'Not used : just for code clarity

        End Try

    End Function

    Function GetValueFromFile(ByVal file As String, ByVal key As String) As String

        Dim line As String = ""
        Dim count As Integer = 0

        Try

            Using reader As StreamReader = New StreamReader(file)

                Do While (Not line Is Nothing)

                    line = reader.ReadLine

                    If line.StartsWith(key) Then
                        If line.Length > key.Length Then

                            'Subtract the key length, so the value remains
                            Dim value As String = line.Substring(key.Length)

                            'Return the value, without any blank spance before/after
                            Return value.Trim

                        Else
                            Return "No value" 'TODO : Better use "" to match smthng smwhr ?
                        End If
                    End If

                Loop

                'Value not found
                Return "No match"

            End Using

        Catch ex As Exception

            Return "Error parsing the file" 'Not used : just for code clarity

        End Try

    End Function

    Function GetLineInFile(ByVal file As String, ByVal key As String, ByVal pos As Integer) As Integer

        Dim line As String = ""
        Dim counter As Integer = 0
        Dim skipped As Integer = 0

        Try

            Using reader As StreamReader = New StreamReader(file)

                Do While (Not line Is Nothing)

                    line = reader.ReadLine
                    counter += 1

                    If line.StartsWith(key) Then
                        If skipped = pos Then

                            'Value found : Return line number
                            Return counter

                        Else
                            skipped += 1

                        End If
                    End If

                Loop

                'Value not found
                Return 0

            End Using

        Catch ex As Exception

            Return 0 'Error reading the file

        End Try

    End Function

    Function GetLineInFile(ByVal file As String, ByVal key As String) As Integer

        Dim line As String = ""
        Dim counter As Integer = 0

        Try

            Using reader As StreamReader = New StreamReader(file)

                Do While (Not line Is Nothing)

                    line = reader.ReadLine
                    counter += 1

                    If line.StartsWith(key) Then

                        'Value found : Return line number
                        Return counter

                    End If

                Loop

                'Value not found
                Return 0

            End Using

        Catch ex As Exception

            Return 0 'Error reading the file

        End Try

    End Function

    Sub WriteLineInFile(ByVal newText As String, ByVal fileToRead As String, ByVal lineToEdit As Integer)

        If Not lineToEdit = 0 Then

            Dim lines() As String = File.ReadAllLines(fileToRead)
            lines(lineToEdit - 1) = newText
            File.WriteAllLines(fileToRead, lines)

        End If

    End Sub

    Sub WriteToLog(ByVal text As String)

        Using StreamWriter As New StreamWriter(RootDirPath & "log.txt", True)

            StreamWriter.WriteLine(text)

        End Using

    End Sub

    Function GetResolutionFromWindows() As Tuple(Of Integer, Integer)

        'Get Windows screen resolution
        Dim screenWidth As Integer = My.Computer.Screen.Bounds.Size.Width
        Dim screenHeight As Integer = My.Computer.Screen.Bounds.Size.Height

        Return Tuple.Create(screenWidth, screenHeight)

    End Function

    Sub AutoSetResolution()

        If ConfirmedWidth Is Nothing And ConfirmedHeight Is Nothing Then

            'Get screen resolution through Windows
            ConfirmedWidth = My.Computer.Screen.Bounds.Size.Width
            ConfirmedHeight = My.Computer.Screen.Bounds.Size.Height

        Else

            'What to do if settingsWindow has not been displayed yet
            Dim settingsWindow As SettingsWindow = New SettingsWindow()
            settingsWindow.TextBox_Resolution_Width.Text = My.Computer.Screen.Bounds.Size.Width
            settingsWindow.TextBox_Resolution_Height.Text = My.Computer.Screen.Bounds.Size.Height

        End If

    End Sub




    ''' 
    ''' Core tasks
    '''

    Function CheckFile(ByVal wadInfo As FileInfo) As String

        Dim name As String = wadInfo.Name.ToLowerInvariant

        If name = "doom.wad" Or name = "doom2.wad" Or name = "tnt.wad" Or name = "plutonia.wad" Then
            Return "iwad"
        End If

        Dim ext As String = wadInfo.Extension.ToLowerInvariant

        If ext = ".wad" Or ext = ".pk3" Then
            Return "level"
        End If

        Return "invalid"

    End Function

    Function GetPresetsFromFile(ByVal presetFile As String) As List(Of List(Of String))

        Dim line As String = ""
        Dim argsList As List(Of List(Of String)) = New List(Of List(Of String))

        Try

            Using reader As StreamReader = New StreamReader(presetFile)

                Do While (Not line Is Nothing)

                    line = reader.ReadLine

                    If line.IndexOf("Name =") >= 0 Then

                        Dim args As List(Of String) = New List(Of String)

                        Dim start1 As Integer = line.IndexOf("Name =") + "Name =".Length
                        Dim end1 As Integer = line.IndexOf("IWAD =") - "IWAD =".Length
                        Dim start2 As Integer = line.IndexOf("IWAD =") + "IWAD =".Length
                        Dim end2 As Integer = line.IndexOf("Level =")
                        Dim start3 As Integer = line.IndexOf("Level =") + "Level =".Length

                        args.Add(line.Substring(start1, end1).Trim)
                        args.Add(line.Substring(start2, end2 - start2).Trim)
                        args.Add(line.Substring(start3).Trim)

                        argsList.Add(args)
                    Else
                        Continue Do
                    End If

                Loop

                'Value not found
                ' ?

            End Using

        Catch ex As Exception

            WriteToLog(DateTime.Now & " - Error in 'GetPresetsFromFile()'. Exception : " & ex.ToString)

        End Try

        Return argsList

    End Function


End Module
