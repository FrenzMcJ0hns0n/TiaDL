﻿Imports System.Text.RegularExpressions

Public Class SettingsWindow




    Private ReadOnly regex_integersOnly As Regex = New Regex("[^0-9]+")




    Private Sub Window_Loaded(sender As Object, e As RoutedEventArgs)

        'Resolution

        If Not ConfirmedWidth Is Nothing And Not ConfirmedHeight Is Nothing Then

            TextBox_Resolution_Width.Text = ConfirmedWidth
            TextBox_Resolution_Height.Text = ConfirmedHeight

        End If

        'Brutal Doom

        If Not ConfirmedBrutalDoomVersion Is Nothing Then

            'IF BRUTALDOOMVERSION is loaded from settings
            'Affect BrutalDoomVersion in GUI

            'ConfirmedUseBrutalDoom
            'ConfirmedBrutalDoomVersion

        End If

    End Sub

    Private Sub Window_Closed(sender As Object, e As EventArgs)

        ConfirmSettings()
        MessageBox.Show("closed")

    End Sub

    Private Sub ConfirmSettings()

        ConfirmedWidth = TextBox_Resolution_Width.Text
        ConfirmedHeight = TextBox_Resolution_Height.Text

    End Sub

    Private Sub Button_GetSetResolution_Click(sender As Object, e As RoutedEventArgs) Handles Button_GetSetResolution.Click

        'Get Windows screen resolution
        Dim screenWidth As Integer = My.Computer.Screen.Bounds.Size.Width
        Dim screenHeight As Integer = My.Computer.Screen.Bounds.Size.Height

        TextBox_Resolution_Width.Text = screenWidth
        TextBox_Resolution_Height.Text = screenHeight

    End Sub

    Private Sub TextBox_Resolution_Width_PreviewTextInput(sender As Object, e As TextCompositionEventArgs) Handles TextBox_Resolution_Width.PreviewTextInput

        'Restrict input to integers
        e.Handled = regex_integersOnly.IsMatch(e.Text)

    End Sub

    Private Sub TextBox_Resolution_Height_PreviewTextInput(sender As Object, e As TextCompositionEventArgs) Handles TextBox_Resolution_Height.PreviewTextInput

        'Restrict input to integers
        e.Handled = regex_integersOnly.IsMatch(e.Text)

    End Sub

    Private Sub Button_SaveSettings_Click(sender As Object, e As RoutedEventArgs) Handles Button_SaveSettings.Click

        Close()

    End Sub

End Class
