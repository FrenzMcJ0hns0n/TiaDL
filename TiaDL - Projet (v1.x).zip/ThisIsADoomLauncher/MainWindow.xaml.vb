﻿Imports System.IO
Imports System.Reflection

Class MainWindow

    Private Sub Window_Loaded(sender As Object, e As RoutedEventArgs)

        Try

            ExePath = Assembly.GetEntryAssembly.Location
            RootDirPath = Path.GetDirectoryName(ExePath) & "\"



            'Tests

            'If ConfirmedWidth Is Nothing Then
            '    MessageBox.Show("ConfirmedWidth is null")
            'Else
            '    MessageBox.Show(ConfirmedWidth)
            'End If

            ConfirmedWidth = My.Settings.Width
            ConfirmedHeight = My.Settings.Height


            CheckDirectories()
            SetGzdoomIni()
            AutoSetResolution()

            'A ENLEVER

            'If File.Exists(RootDirPath & "settings.txt") Then
            '    ParseSettingsFile()
            'Else
            '    CreateSettingsFile()
            'End If

        Catch ex As Exception
            WriteToLog(DateTime.Now & " - Error in 'Window_Loaded()'. Exception : " & ex.ToString)
        End Try

    End Sub


    Private Sub CheckDirectories() 'put outside MainWindow.xaml.vb

        Try

            Dim setupError As Boolean = False
            Dim errorText As String = ""

            If Directory.Exists(RootDirPath & "gzdoom") Then
                GzdoomDirPath = RootDirPath & "gzdoom\"
            Else
                setupError = True
                errorText &= "/gzdoom/" & Environment.NewLine
            End If

            If Directory.Exists(RootDirPath & "iwads") Then
                IwadDirPath = RootDirPath & "iwads\"
            Else
                setupError = True
                errorText &= "/iwads/" & Environment.NewLine
            End If

            If Directory.Exists(RootDirPath & "mods") Then
                ModDirPath = RootDirPath & "mods\"
                PopulateBrutalVersions()
            Else
                setupError = True
                errorText &= "/mods/" & Environment.NewLine
            End If

            If Directory.Exists(RootDirPath & "music") Then
                MusicDirPath = RootDirPath & "music\"
            Else
                setupError = True
                errorText &= "/music/" & Environment.NewLine
            End If

            If Directory.Exists(RootDirPath & "wads") Then
                LevelDirPath = RootDirPath & "wads\"
            Else
                setupError = True
                errorText &= "/wads/" & Environment.NewLine
            End If


            If setupError = True Then

                Dim output As String = String.Format("Setup error.{0}The following folders are not found :{1}{2}{3}",
                                                     Environment.NewLine & Environment.NewLine,
                                                     Environment.NewLine & errorText,
                                                     Environment.NewLine & "Did you move the exe file ?",
                                                     Environment.NewLine & "These directories should be visible right when you click 'Explore folder'")
                MessageBox.Show(output)
                Button_Launch.Foreground = Brushes.Red
                Button_Launch.FontSize = 18
                Button_Launch.Content = "Setup error"

                WriteToLog(DateTime.Now & " - Setup error : director[y-ies] not found.")
            End If

        Catch ex As Exception
            WriteToLog(DateTime.Now & " - Error in 'CheckDirectories()'. Exception : " & ex.ToString)
        End Try

    End Sub


    Private Sub SetGzdoomIni()

        If File.Exists(GzdoomDirPath & "gzdoom-model.ini") Then
            File.Move(
                GzdoomDirPath & "gzdoom-model.ini",
                GzdoomDirPath & "gzdoom-" & Environment.UserName & ".ini"
            )
        End If

    End Sub


    Private Sub ParseSettingsFile()

        'A ENLEVER

        'Try

        '    Dim value As String

        '    'Width
        '    value = GetValueFromFile(RootDirPath & "settings.txt", "width", 0)
        '    If Integer.TryParse(value, LoadedWidth) Then
        '        TextBox_ResWidth.Text = CType(LoadedWidth, String)
        '    End If


        '    'Height
        '    value = GetValueFromFile(RootDirPath & "settings.txt", "height", 0)
        '    If Integer.TryParse(value, LoadedHeight) Then
        '        TextBox_ResHeight.Text = CType(LoadedHeight, String)
        '    End If


        '    'Fullscreen
        '    value = GetValueFromFile(RootDirPath & "settings.txt", "fullscreen", 0)
        '    If Integer.TryParse(value, LoadedFullscreen) Then
        '        If LoadedFullscreen = 1 Then
        '            CheckBox_Fullscreen.IsChecked = True
        '        End If
        '    End If


        '    'Turbo mode
        '    value = GetValueFromFile(RootDirPath & "settings.txt", "turbo", 0)
        '    If Integer.TryParse(value, LoadedTurbo) Then
        '        If LoadedTurbo = 1 Then
        '            CheckBox_EnableTurbo.IsChecked = True
        '        End If
        '    End If


        '    'Favourite BD version
        '    value = GetValueFromFile(RootDirPath & "settings.txt", "favouriteBDversion", 0)

        '    If Not value = "" Then
        '        Dim fileInfo_favBD As FileInfo = New FileInfo(value)

        '        If fileInfo_favBD.Extension.ToLowerInvariant = ".pk3" Then
        '            LoadedFavouriteBrutal = value
        '            TextBox_FavBrutalVersion.Text = LoadedFavouriteBrutal
        '        Else
        '            MessageBox.Show("Error : The value found for 'favouriteBDversion' in 'settings.txt' isn't refering to a valid .pk3 file ")
        '        End If
        '    End If


        '    'Last IWAD launched
        '    value = GetValueFromFile(RootDirPath & "settings.txt", "lastIwadLaunched", 0)

        '    If Not value = "" Then 'useless (always something else than "")
        '        Dim fileInfo_iwad As FileInfo = New FileInfo(value)

        '        If fileInfo_iwad.Extension.ToLowerInvariant = ".wad" Then
        '            LoadedLastLaunchedIwad = fileInfo_iwad.Name
        '            TextBox_IwadToLaunch.Text = LoadedLastLaunchedIwad
        '        Else
        '            MessageBox.Show("Error : The value found for 'lastIwadLaunched' in 'settings.txt' isn't refering to a valid .wad file ")
        '        End If
        '    End If 'useless


        '    'Last Wad launched
        '    value = GetValueFromFile(RootDirPath & "settings.txt", "lastWadLaunched", 0)

        '    If Not value = "" Then 'useless (always something else than "")
        '        Dim fileInfo_wad As FileInfo = New FileInfo(value)

        '        If fileInfo_wad.Extension.ToLowerInvariant = ".wad" Or fileInfo_wad.Extension.ToLowerInvariant = ".pk3" Then
        '            LoadedLastWadLaunched = fileInfo_wad.FullName
        '            TextBox_LevelToLaunch.Text = fileInfo_wad.Name
        '        Else
        '            MessageBox.Show("Error : The value found for 'lastWadLaunched' in 'settings.txt' isn't refering to a valid .wad/.pk3 file ")
        '        End If
        '    End If 'useless


        'Catch ex As Exception
        '    WriteToLog(DateTime.Now & " - Error in 'ParseSettingsFile()'. Exception : " & ex.ToString)
        'End Try

    End Sub


    Private Sub PopulateBrutalVersions()

        Try

            Dim files() = Directory.GetFiles(ModDirPath)

            For Each file As String In files
                Dim name As String = New FileInfo(file).Name
                ComboBox_BrutalDoomVersion.Items.Add(name)
            Next

        Catch ex As Exception
            WriteToLog(DateTime.Now & " - Error in 'PopulateBrutalVersions()'. Exception : " & ex.ToString)
        End Try

    End Sub


    Private Sub CreateSettingsFile()

        'A ENLEVER

        'Try

        '    Using writer As StreamWriter = New StreamWriter(RootDirPath & "settings.txt")
        '        writer.WriteLine("width ")
        '        writer.WriteLine("height ")
        '        writer.WriteLine("fullscreen ")
        '        writer.WriteLine("turbo ")
        '        writer.WriteLine("favouriteBDversion ")
        '        writer.WriteLine("lastIwadLaunched ")
        '        writer.WriteLine("lastWadLaunched ")
        '    End Using

        'Catch ex As Exception
        '    WriteToLog(DateTime.Now & " - Error in 'CreateSettingsFile()'. Exception : " & ex.ToString)
        'End Try

    End Sub




    '''
    ''' IWAD files
    '''

    Private Sub Button_SetIwad_Doom_Click(sender As Object, e As RoutedEventArgs) Handles Button_SetIwad_Doom.Click

        Dim doom As String = IwadDirPath & "Doom.wad"

        If File.Exists(doom) Then

            Dim fileInfo As FileInfo = New FileInfo(doom)
            TextBox_SelectedIwad_Custom.ClearValue(FontStyleProperty)
            TextBox_SelectedIwad_Custom.ClearValue(ForegroundProperty)
            TextBox_SelectedIwad_Custom.Text = "[...]\TiaDL\iwads\" & fileInfo.Name

        Else

            MessageBox.Show("Error : File 'Doom.wad' not found in folder TiaDL\iwads\")

        End If


    End Sub


    Private Sub Button_SetIwad_Doom2_Click(sender As Object, e As RoutedEventArgs) Handles Button_SetIwad_Doom2.Click

        Dim doom2 As String = IwadDirPath & "Doom2.wad"

        If File.Exists(doom2) Then

            Dim fileInfo As FileInfo = New FileInfo(doom2)
            TextBox_SelectedIwad_Custom.ClearValue(FontStyleProperty)
            TextBox_SelectedIwad_Custom.ClearValue(ForegroundProperty)
            TextBox_SelectedIwad_Custom.Text = "[...]\TiaDL\iwads\" & fileInfo.Name

        Else

            MessageBox.Show("Error : File 'Doom2.wad' not found in folder TiaDL\iwads\")

        End If

    End Sub




    '''
    ''' Wad files
    '''

    Private Sub TextBox_wad_file_PreviewDragOver(sender As Object, e As DragEventArgs)

        e.Handled = True

    End Sub

    Private Sub TextBox_wad_file_Drop(sender As Object, e As DragEventArgs)

        Try

            Dim file() As String = CType(e.Data.GetData(DataFormats.FileDrop), String())
            Dim fileInfo As FileInfo = New FileInfo(file(0))

            If CheckFile(fileInfo) = "level" Then

                TextBox_DropWadFile.ClearValue(FontStyleProperty)
                TextBox_DropWadFile.ClearValue(ForegroundProperty)
                TextBox_DropWadFile.Text = fileInfo.FullName
                'TextBox_ShowWadToLaunch.Text = fileInfo.Name

            ElseIf CheckFile(fileInfo) = "iwad" Then

                MessageBox.Show("Error : this file is an IWAD")

            Else

                MessageBox.Show("Error : not a .wad/.pk3 file")
                'ResetInput_wad(False) 'Same as above for IWAD

            End If

        Catch ex As Exception
            WriteToLog(DateTime.Now & " - Error in 'TextBox_wad_file_Drop()'. Exception : " & ex.ToString)
        End Try

    End Sub

    Private Sub Button_Reset_wad_input_Click(sender As Object, e As RoutedEventArgs) Handles Button_Reset_wad_input.Click

        TextBox_DropWadFile.FontStyle = FontStyles.Italic
        TextBox_DropWadFile.Foreground = New BrushConverter().ConvertFrom("#777")
        TextBox_DropWadFile.Text = "Level selection : Drop a .wad/.pk3 file here ..."

        'TextBox_ShowWadToLaunch.Text = ""

    End Sub

    ' REUSE FOR SET AS LAUNCH PARAMS
    'Private Sub Button_ValidDroppedWad_Click(sender As Object, e As RoutedEventArgs) Handles Button_ValidDroppedWad.Click

    '    If Not TextBox_DropWadFile.Text = "Drop a .wad/.pk3 file here ..." Then

    '        TextBox_ShowWadToLaunch.Text = New FileInfo(TextBox_DropWadFile.Text).Name

    '    End If

    'End Sub

    Private Sub Button_SearchDoomWorldDB_Click(sender As Object, e As RoutedEventArgs) Handles Button_SearchDoomWorldDB.Click

        Dim url As String = "https://www.doomworld.com/idgames/levels/"
        Process.Start(url)

    End Sub










    '''
    ''' Brutal Doom GUI Items
    ''' 

    Private Sub Button_Reset_FoundBru_input_Click(sender As Object, e As RoutedEventArgs) Handles Button_Reset_FoundBru_input.Click

        ComboBox_BrutalDoomVersion.SelectedItem = Nothing

    End Sub

    Private Sub Button_DefineFavBrutalVersion_Click(sender As Object, e As RoutedEventArgs) Handles Button_DefineFavBrutalVersion.Click

        TextBox_FavBrutalVersion.Text = ComboBox_BrutalDoomVersion.Text

    End Sub

    Private Sub Button_Reset_FavBru_input_Click(sender As Object, e As RoutedEventArgs) Handles Button_Reset_FavBru_input.Click

        TextBox_FavBrutalVersion.Text = ""

    End Sub










    '''
    ''' Lower buttons
    ''' 

    Private Sub Button_ExploreFolder_Click(sender As Object, e As RoutedEventArgs) Handles Button_ExploreFolder.Click

        Process.Start(RootDirPath)

    End Sub

    Private Sub Button_Launch_Click(sender As Object, e As RoutedEventArgs) Handles Button_Launch.Click

        Try

            'If Button_Launch.Content = "Play" Then

            If TextBox_IwadToLaunch.Text = "" Then
                MessageBox.Show("Error : an IWAD must be selected")
                Return
            Else
                Dim bcli = BuildCommandLineInstructions()
                LaunchProcess(bcli)
                SaveNewSettings()
            End If

            'If TextBox_ResWidth.Text = "" Or TextBox_ResHeight.Text = "" Then
            '    MessageBox.Show("Error : please choose a screen resolution")
            '    Return
            'End If

            'If TextBox_IwadToLaunch.Text = "" Then
            '    MessageBox.Show("Error : an IWAD must be selected")
            '    Return
            'End If



            'Else 'Setup error
            '    Dim output As String = String.Format("Setup error : The TiaDL folder must contain :{0}{1}{2}{3}{4}{5}{6}{7}{8}{9}{10}{11}",
            '                                         Environment.NewLine,
            '                                         Environment.NewLine & "- /gzdoom/ folder",
            '                                         Environment.NewLine & "- /iwads/ folder",
            '                                         Environment.NewLine & "- /mods/ folder",
            '                                         Environment.NewLine & "- /music/ folder",
            '                                         Environment.NewLine & "- /wads/ folder",
            '                                         Environment.NewLine & "- 'info.txt' file (optional)",
            '                                         Environment.NewLine & "- 'log.txt' file (optional)",
            '                                         Environment.NewLine & "- 'settings.txt' file (optional)",
            '                                         Environment.NewLine & "- 'ThisIsADoomLauncher.exe' executable",
            '                                         Environment.NewLine,
            '                                         Environment.NewLine & "Please check picture 'help.png' for further help")
            '    MessageBox.Show(output)

            'End If

        Catch ex As Exception
            WriteToLog(DateTime.Now & " - Error in 'Button_Launch_Click()'. Exception : " & ex.ToString)
        End Try

    End Sub

    Private Function BuildCommandLineInstructions()  'Should be done outside MainWindow.xaml.vb, like in separate class

        Try

            'Set resolution and fullscreen mode ------------------------------------------------------------------

            'ConfirmedWidth = " -width " & TextBox_ResWidth.Text
            'ConfirmedHeight = " -height " & TextBox_ResHeight.Text

            'If ConfirmedFullscreen Is Nothing Then

            '    'Fullscreen mode is enabled unless user choose otherwise
            '    ConfirmedFullscreen = " +fullscreen 1"

            'End If



            'Set IWAD path ------------------------------------------------------------------

            If File.Exists(TextBox_IwadToLaunch.Text) Then

                'File's full path is written in TextBox
                ConfirmedIwad = " -iwad " & """" & TextBox_IwadToLaunch.Text & """"

            Else

                'File's filename only is written in TextBox : so we add 'DirIwads' before it
                ConfirmedIwad = " -iwad " & """" & IwadDirPath & TextBox_IwadToLaunch.Text & """"

            End If


            'Set Level/Wad path ------------------------------------------------------------------

            ConfirmedLevel = "" 'Don't use any level, if the requirements below are not met

            If Not TextBox_LevelToLaunch.Text = "" Then

                If File.Exists(TextBox_LevelToLaunch.Text) Then

                    'File's full path is written in TextBox
                    ConfirmedLevel += " -file " & """" & TextBox_LevelToLaunch.Text & """"

                ElseIf File.Exists(LevelDirPath & TextBox_LevelToLaunch.Text) Then

                    'File's filename only is written in TextBox : so we add 'DirWads' before it
                    ConfirmedLevel += " -file " & """" & LevelDirPath & TextBox_LevelToLaunch.Text & """"

                End If

            End If


            'Set Brutal Doom version ------------------------------------------------------------------

            'If Not ConfirmedBdVersion Is Nothing Then

            'End If


            'If Not TextBox_FavBrutalVersion.Text = "" Then
            '    ConfirmedBdVersion += " -file " & """" & DirMods & TextBox_FavBrutalVersion.Text & """"
            'Else
            '    ConfirmedBdVersion += " -file " & """" & DirMods & ComboBox_BrutalDoomVersion.Text & """"
            'End If


            ' Set Music ------------------------------------------------------------------

            'ConfirmedMusicMod = ""

            If CheckBox_Load_DoomMetal.IsChecked Then
                ConfirmedMusicMod += " -file " & """" & MusicDirPath & "DoomMetalVol4.wad" & """"
            End If


            ' Set Player movespeed ------------------------------------------------------------------

            'ConfirmedTurbo = ""

            If CheckBox_EnableTurbo.IsChecked Then
                ConfirmedTurbo += " -turbo 125"
            End If


            'Build the string with arguments ------------------------------------------------------------------

            Dim args = "/c start " & """""" & " " & """" & GzdoomDirPath & "gzdoom.exe" & """" &
                       ConfirmedWidth &
                       ConfirmedHeight &
                       ConfirmedFullscreen &
                       ConfirmedIwad &
                       ConfirmedLevel &
                       ConfirmedBrutalDoomVersion &
                       ConfirmedMusicMod &
                       ConfirmedTurbo

            WriteToLog(DateTime.Now & " - CommandLine :" & Environment.NewLine & args)

            Return args

        Catch ex As Exception

            WriteToLog(DateTime.Now & " - Error in 'BuildCommandLineInstructions()'. Exception : " & ex.ToString)
            Return ""

        End Try

    End Function

    Private Sub LaunchProcess(ByVal args As String)

        Dim psi As New ProcessStartInfo("cmd.exe") With {
            .UseShellExecute = False,
            .CreateNoWindow = True,
            .Arguments = args
        }

        Process.Start(psi)

    End Sub

    Private Sub SaveNewSettings()

        With My.Settings

            .Width = ConfirmedWidth
            .Height = ConfirmedHeight
            .Fullscreen = ConfirmedFullscreen
            .UseBrutalDoom = ConfirmedUseBrutalDoom
            .BrutalDoomVersion = ConfirmedBrutalDoomVersion
            .LastLaunchedIwad = ConfirmedIwad
            .LastLaunchedLevel = ConfirmedLevel
            .Save()
            'add 'Engine = ConfirmedEngine

        End With

    End Sub

    Private Sub WriteNewSettings() 'TODO : use .NET settings

        ' A ENLEVER

        'Try

        '    Dim line As Integer = 0

        '    If Not LoadedWidth = CInt(TextBox_ResWidth.Text) Then
        '        line = GetLineInFile(RootDirPath & "settings.txt", "width")
        '        WriteLineInFile("width " & TextBox_ResWidth.Text, RootDirPath & "settings.txt", line)
        '    End If

        '    If Not LoadedHeight = CInt(TextBox_ResHeight.Text) Then
        '        line = GetLineInFile(RootDirPath & "settings.txt", "height")
        '        WriteLineInFile("height " & TextBox_ResHeight.Text, RootDirPath & "settings.txt", line)
        '    End If

        '    If Not LoadedFullscreen = CInt(Int(CheckBox_Fullscreen.IsChecked)) Then
        '        line = GetLineInFile(RootDirPath & "settings.txt", "fullscreen")
        '        WriteLineInFile("fullscreen " & CInt(Int(CheckBox_Fullscreen.IsChecked)).ToString, RootDirPath & "settings.txt", line)
        '    End If

        '    If Not LoadedTurbo = CInt(Int(CheckBox_EnableTurbo.IsChecked)) Then
        '        line = GetLineInFile(RootDirPath & "settings.txt", "turbo")
        '        WriteLineInFile("turbo " & CInt(Int(CheckBox_EnableTurbo.IsChecked)).ToString, RootDirPath & "settings.txt", line)
        '    End If

        '    If Not LoadedFavouriteBrutal = TextBox_FavBrutalVersion.Text Then
        '        line = GetLineInFile(RootDirPath & "settings.txt", "favouriteBDversion")
        '        WriteLineInFile("favouriteBDversion " & TextBox_FavBrutalVersion.Text, RootDirPath & "settings.txt", line)
        '    End If

        '    If Not LoadedLastLaunchedIwad = TextBox_IwadToLaunch.Text Then
        '        line = GetLineInFile(RootDirPath & "settings.txt", "lastIwadLaunched")
        '        WriteLineInFile("lastIwadLaunched " & TextBox_IwadToLaunch.Text, RootDirPath & "settings.txt", line)
        '    End If


        '    ' Consider the case of dropped wad file

        '    If TextBox_LevelToLaunch.Text = "" Then

        '        ' Just an Iwad launched
        '        line = GetLineInFile(RootDirPath & "settings.txt", "lastWadLaunched")
        '        WriteLineInFile("lastWadLaunched ", RootDirPath & "settings.txt", line)

        '    Else
        '        If TextBox_DropWadFile.Text = "Drop a .wad/.pk3 file here ..." Then

        '            If File.Exists(DirWads & TextBox_LevelToLaunch.Text) Then

        '                Dim fileInfo As FileInfo = New FileInfo(TextBox_LevelToLaunch.Text)
        '                line = GetLineInFile(RootDirPath & "settings.txt", "lastWadLaunched")
        '                WriteLineInFile("lastWadLaunched " & fileInfo.Name, RootDirPath & "settings.txt", line)
        '            Else
        '                ' so it may come from the LastLaunchedWad
        '                If File.Exists(LoadedLastWadLaunched) Then
        '                    line = GetLineInFile(RootDirPath & "settings.txt", "lastWadLaunched")
        '                    WriteLineInFile("lastWadLaunched " & LoadedLastWadLaunched, RootDirPath & "settings.txt", line)
        '                End If
        '            End If
        '        Else

        '            Dim fileInfo As FileInfo = New FileInfo(TextBox_DropWadFile.Text)
        '            line = GetLineInFile(RootDirPath & "settings.txt", "lastWadLaunched")
        '            WriteLineInFile("lastWadLaunched " & fileInfo.FullName, RootDirPath & "settings.txt", line)

        '        End If
        '    End If

        'Catch ex As Exception
        '    WriteToLog(DateTime.Now & " - Error in 'WriteNewSettings()'. Exception : " & ex.ToString)
        'End Try

    End Sub





#Region "Common presets 1-12 button click"

    Private Sub Button_Preset_UltimateDoom_Click(sender As Object, e As RoutedEventArgs) Handles Button_Preset_UltimateDoom.Click

        ApplyConfirmedFiles("Doom.wad", "")

    End Sub

    Private Sub Button_Preset_Doom2_Click(sender As Object, e As RoutedEventArgs) Handles Button_Preset_Doom2.Click

        ApplyConfirmedFiles("Doom2.wad", "")

    End Sub

    Private Sub Button_Preset_TNT_Click(sender As Object, e As RoutedEventArgs) Handles Button_Preset_TNT.Click

        ApplyConfirmedFiles("TNT.wad", "")

    End Sub

    Private Sub Button_Preset_Plutonia_Click(sender As Object, e As RoutedEventArgs) Handles Button_Preset_Plutonia.Click

        ApplyConfirmedFiles("Plutonia.wad", "")

    End Sub

    Private Sub Button_Preset_2002ADO_Click(sender As Object, e As RoutedEventArgs) Handles Button_Preset_2002ADO.Click

        ApplyConfirmedFiles("Doom.wad", "2002ad10.wad")

    End Sub

    Private Sub Button_Preset_Icarus_Click(sender As Object, e As RoutedEventArgs) Handles Button_Preset_Icarus.Click

        ApplyConfirmedFiles("Doom2.wad", "ICARUS.wad")

    End Sub

    Private Sub Button_Preset_Requiem_Click(sender As Object, e As RoutedEventArgs) Handles Button_Preset_Requiem.Click

        ApplyConfirmedFiles("Doom2.wad", "Requiem.wad")

    End Sub

    Private Sub Button_Preset_Plutonia2_Click(sender As Object, e As RoutedEventArgs) Handles Button_Preset_Plutonia2.Click

        ApplyConfirmedFiles("Doom2.wad", "PL2.wad")

    End Sub

    Private Sub Button_Preset_HellRevealed_Click(sender As Object, e As RoutedEventArgs) Handles Button_Preset_HellRevealed.Click

        ApplyConfirmedFiles("Doom2.wad", "hr.wad")

    End Sub

    Private Sub Button_Preset_HellRevealed2_Click(sender As Object, e As RoutedEventArgs) Handles Button_Preset_HellRevealed2.Click

        ApplyConfirmedFiles("Doom2.wad", "hr2final.wad")

    End Sub

    Private Sub Button_Preset_DTST_Click(sender As Object, e As RoutedEventArgs) Handles Button_Preset_DTST.Click

        ApplyConfirmedFiles("Doom2.wad", "DTS-T.pk3")

    End Sub

    Private Sub Button_Preset_PlutoniaRevisited_Click(sender As Object, e As RoutedEventArgs) Handles Button_Preset_PlutoniaRevisited.Click

        ApplyConfirmedFiles("Doom2.wad", "RCP.wad")

    End Sub

    Private Sub ApplyConfirmedFiles(ByVal iwad As String, ByVal level As String)

        ConfirmedIwad = iwad
        ConfirmedLevel = level

        TextBox_IwadToLaunch.Text = ConfirmedIwad
        TextBox_LevelToLaunch.Text = ConfirmedLevel

    End Sub

    'Whose is this ?
    Private Sub Button_Click(sender As Object, e As RoutedEventArgs)

        Dim window As Window = New Window()
        window.Show()

    End Sub

#End Region




    Private Sub Button_Menu_Settings_Click(sender As Object, e As RoutedEventArgs) Handles Button_Menu_Settings.Click

        Dim settingsWindow As SettingsWindow = New SettingsWindow()
        settingsWindow.ShowDialog()

    End Sub


    Private Sub Button_Menu_Help_Click(sender As Object, e As RoutedEventArgs) Handles Button_Help.Click



    End Sub






    Private Sub Button_Test_AddPreset_Click(sender As Object, e As RoutedEventArgs) Handles Button_Test_AddPreset.Click

        Dim listOfList As List(Of IEnumerable(Of Object)) = New List(Of IEnumerable(Of Object))

        listOfList = ReturnPresetsData(GetPresetsFromFile(RootDirPath & "presets.txt"))
        DisplayUserPresets(listOfList)

    End Sub


    Private Function ReturnPresetsData(ByVal presets As List(Of List(Of String))) As List(Of IEnumerable(Of Object))

        'Destination
        Dim buttons As List(Of Button) = New List(Of Button)
        Dim values As List(Of String) = New List(Of String)
        Dim buttonsAndValues As List(Of IEnumerable(Of Object)) = New List(Of IEnumerable(Of Object))


        'Parse data then return it

        Dim tuple As List(Of String) 'tuple example : MyPresetName, Doom2, LevelPath

        For Each tuple In presets

            If Not tuple(0) = "" And Not tuple(0) Is Nothing Then

                WriteToLog("Test args/tuples : " & tuple(0) & tuple(1) & tuple(2)) 'debug

                Dim button As Button = New Button With {
                    .Content = tuple(0),
                    .FontSize = 14,
                    .Margin = New Thickness(0, 0, 0, 2)
                }

                buttons.Add(button)
                'TODO : better values storage ?
                'For now it's values(0-1-2) for preset1, values(3,4,5) for preset2, etc.
                values.Add(tuple(0))
                values.Add(tuple(1))
                values.Add(tuple(2))

                buttonsAndValues.Add(buttons)
                buttonsAndValues.Add(values)
            Else
                MessageBox.Show("was """" or nothing")
            End If

        Next

        Return buttonsAndValues

    End Function

    Private Sub DisplayUserPresets(ByVal presets_buttonsAndValues As List(Of IEnumerable(Of Object)))

        'list(0) = buttons
        'list(1) = values = tuple(0), tuple(1), tuple(2) NOT REALLY, MORE LIKE val(0), val(1), ... val(5), ...

        Dim btns As List(Of Button) = presets_buttonsAndValues(0)
        Dim vals As List(Of String) = presets_buttonsAndValues(1)

        Dim i As Integer = 0

        For counter As Integer = 0 To btns.Count - 1

            With btns(counter)

                Dim presetName As String = vals(i + 0)
                Dim presetIwad As String = vals(i + 1)
                Dim presetLvel As String = vals(i + 2)

                AddHandler btns(counter).Click, Sub(sender, e) HandleUserPresetClick(presetName, presetIwad, presetLvel)

                StackPanel_DisplayUserPresets.Children.Add(btns(counter))

                i += 3

            End With

        Next

    End Sub

    Private Sub HandleUserPresetClick(name As String, iwad As String, level As String)

        'Confirm or don't confirm IWAD and Level as valid launch parameters

        Dim fileInfo As FileInfo

        fileInfo = New FileInfo(iwad)

        If CheckFile(fileInfo) = "iwad" Then
            ConfirmedIwad = IwadDirPath & fileInfo.Name
            TextBox_IwadToLaunch.Text = fileInfo.Name
        End If

        fileInfo = New FileInfo(level)

        If CheckFile(fileInfo) = "level" Then
            ConfirmedLevel = level
            TextBox_LevelToLaunch.Text = fileInfo.FullName
        End If

        WriteToLog(DateTime.Now & " - From 'HandleUserPresetClick()' : " & Environment.NewLine &
                   "Preset IWAD : " & iwad & Environment.NewLine &
                   "Preset level : " & level)

    End Sub

    Private Sub Button_test_Click(sender As Object, e As RoutedEventArgs) Handles Button_test.Click
        MessageBox.Show(ConfirmedWidth & " - " & ConfirmedHeight)
        SaveNewSettings()
    End Sub

End Class
